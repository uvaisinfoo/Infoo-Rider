const express = require('express');
const path = require('path');
const Database = require('better-sqlite3');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const db = new Database(path.join(__dirname, 'infoo_rider.db'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL CHECK(role IN ('customer','driver','admin')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS rides (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL,
  driver_id INTEGER,
  pickup TEXT NOT NULL,
  destination TEXT NOT NULL,
  vehicle_type TEXT NOT NULL CHECK(vehicle_type IN ('bike','auto','car')),
  payment_method TEXT NOT NULL CHECK(payment_method IN ('cash','upi')),
  estimated_fare INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'requested'
    CHECK(status IN ('requested','accepted','arriving','started','completed','cancelled')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(customer_id) REFERENCES users(id),
  FOREIGN KEY(driver_id) REFERENCES users(id)
);
`);
app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, 'public')));

const prices = { bike: 45, auto: 80, car: 140 };
const validStatuses = new Set(['requested','accepted','arriving','started','completed','cancelled']);

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'Infoo Rider API', version: '0.1.0' }));

app.post('/api/users', (req, res) => {
  const { name, phone, role } = req.body || {};
  if (!name || !phone || !/^[0-9]{10}$/.test(String(phone))) {
    return res.status(400).json({ error: 'name and a valid 10-digit phone are required' });
  }
  if (!['customer','driver'].includes(role)) {
    return res.status(400).json({ error: 'role must be customer or driver' });
  }
  try {
    const info = db.prepare('INSERT INTO users(name,phone,role) VALUES(?,?,?)')
      .run(String(name).trim(), String(phone), role);
    res.status(201).json(db.prepare('SELECT id,name,phone,role,created_at FROM users WHERE id=?').get(info.lastInsertRowid));
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return res.status(409).json({ error: 'phone already registered' });
    res.status(500).json({ error: 'could not create user' });
  }
});

app.get('/api/users', (_req, res) => {
  res.json(db.prepare("SELECT id,name,phone,role,created_at FROM users WHERE role != 'admin' ORDER BY id DESC LIMIT 500").all());
});

app.post('/api/rides', (req, res) => {
  const { customerId, pickup, destination, vehicleType, paymentMethod } = req.body || {};
  if (!Number.isInteger(Number(customerId)) || !String(pickup || '').trim() || !String(destination || '').trim()) {
    return res.status(400).json({ error: 'customerId, pickup and destination are required' });
  }
  if (!(vehicleType in prices)) return res.status(400).json({ error: 'vehicleType must be bike, auto, or car' });
  if (!['cash','upi'].includes(paymentMethod)) return res.status(400).json({ error: 'paymentMethod must be cash or upi' });
  const customer = db.prepare("SELECT id FROM users WHERE id=? AND role='customer'").get(Number(customerId));
  if (!customer) return res.status(404).json({ error: 'customer not found; register a customer first' });
  const info = db.prepare(`INSERT INTO rides(customer_id,pickup,destination,vehicle_type,payment_method,estimated_fare)
    VALUES(?,?,?,?,?,?)`).run(Number(customerId), String(pickup).trim().slice(0,200),
      String(destination).trim().slice(0,200), vehicleType, paymentMethod, prices[vehicleType]);
  res.status(201).json(db.prepare('SELECT * FROM rides WHERE id=?').get(info.lastInsertRowid));
});

app.get('/api/rides', (_req, res) => {
  const rows = db.prepare(`SELECT r.*, c.name AS customer_name, c.phone AS customer_phone,
    d.name AS driver_name FROM rides r
    JOIN users c ON c.id=r.customer_id LEFT JOIN users d ON d.id=r.driver_id
    ORDER BY r.id DESC LIMIT 500`).all();
  res.json(rows);
});

app.get('/api/driver/rides', (req, res) => {
  const driverId = Number(req.query.driverId);
  if (!Number.isInteger(driverId) || driverId <= 0) return res.status(400).json({ error: 'driverId is required' });
  const driver = db.prepare("SELECT id FROM users WHERE id=? AND role='driver'").get(driverId);
  if (!driver) return res.status(404).json({ error: 'driver not found' });
  res.json(db.prepare(`SELECT * FROM rides WHERE status='requested' OR driver_id=? ORDER BY id DESC LIMIT 200`).all(driverId));
});

app.patch('/api/rides/:id/status', (req, res) => {
  const id = Number(req.params.id);
  const { status, driverId } = req.body || {};
  if (!validStatuses.has(status)) return res.status(400).json({ error: 'invalid status' });
  const ride = db.prepare('SELECT * FROM rides WHERE id=?').get(id);
  if (!ride) return res.status(404).json({ error: 'ride not found' });
  if (status === 'accepted') {
    if (!Number.isInteger(Number(driverId))) return res.status(400).json({ error: 'driverId is required to accept a ride' });
    const driver = db.prepare("SELECT id FROM users WHERE id=? AND role='driver'").get(Number(driverId));
    if (!driver) return res.status(404).json({ error: 'driver not found' });
    const result = db.prepare("UPDATE rides SET driver_id=?, status='accepted' WHERE id=? AND status='requested'").run(Number(driverId), id);
    if (!result.changes) return res.status(409).json({ error: 'ride is no longer available' });
  } else {
    db.prepare('UPDATE rides SET status=? WHERE id=?').run(status, id);
  }
  res.json(db.prepare('SELECT * FROM rides WHERE id=?').get(id));
});

app.get('/admin', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Infoo Rider API running on http://localhost:${PORT}`);
  console.log('WARNING: development starter only; do not expose publicly without authentication and HTTPS.');
});
