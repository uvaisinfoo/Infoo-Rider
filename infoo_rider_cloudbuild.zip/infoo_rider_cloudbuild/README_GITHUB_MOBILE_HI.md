# Android मोबाइल से GitHub पर Infoo Rider APK बनाना

## ज़रूरी बात
यह starter project है। यह workflow Android का **debug APK** बनाने के लिए है। APK बनना build compatibility, GitHub Actions limits और dependencies पर निर्भर करेगा। ऐप अभी production-ready नहीं है।

## मोबाइल से तरीका (GitHub Codespaces)
1. इस ZIP को फोन में डाउनलोड करें और Files ऐप से ZIP extract करें।
2. Chrome में https://github.com खोलें और लॉगिन करें।
3. `+` → `New repository` चुनें। नाम `infoo-rider` रखें, Public या Private चुनें, फिर `Create repository` दबाएँ।
4. Repository के मुख्य पेज पर `Code` → `Codespaces` → `Create codespace on main` चुनें। अगर Codespaces का विकल्प नहीं दिखता या usage limit है, तो आगे बढ़ने के लिए दूसरे cloud development service या कंप्यूटर की मदद चाहिए हो सकती है।
5. Codespaces terminal में यह कमांड चलाएँ (पहले ZIP को Codespaces में upload करना होगा):
   `unzip infoo_rider_cloudbuild.zip -d /tmp/infoo`
   फिर source को repository root में copy करें:
   `cp -a /tmp/infoo/infoo_rider_cloudbuild/. .`
   `git add . && git commit -m "Add Infoo Rider starter and APK workflow" && git push`
6. GitHub repository में `Actions` टैब खोलें। `Build Infoo Rider APK` workflow चुनें। Push के बाद अपने-आप शुरू होना चाहिए; न हो तो `Run workflow` दबाएँ।
7. Build पूरा होने पर workflow के run पर टैप करें। नीचे `Artifacts` में `infoo-rider-debug-apk` चुनकर ZIP डाउनलोड करें।
8. डाउनलोड की गई artifact ZIP को Files ऐप में extract करें। `app-debug.apk` पर टैप करके इंस्टॉल करें। Android पूछे तो केवल तभी browser/files app से install permission दें जब आप अपनी ही build पर भरोसा करते हों।

## ZIP को Codespaces में कैसे लाएँ?
Codespaces VS Code जैसा cloud editor है। Codespaces Explorer में Upload Files विकल्प से ZIP अपलोड करें, फिर terminal में ऊपर के `unzip` commands चलाएँ। ZIP के अंदर मौजूद folder का नाम `infoo_rider_cloudbuild` है।

## सीमाएँ
- Debug APK परीक्षण के लिए है, Play Store release के लिए signed release build नहीं।
- Driver app, OTP, live GPS/maps, push notifications, verified UPI payments, secure admin login और production hosting अभी पूर्ण नहीं हैं।
- Backend को इंटरनेट पर सार्वजनिक रूप से चलाने के लिए सुरक्षित hosting, HTTPS और authentication चाहिए।
