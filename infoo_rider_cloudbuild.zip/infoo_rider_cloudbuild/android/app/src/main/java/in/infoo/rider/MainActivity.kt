package in.infoo.rider

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

// Android emulator can reach the host computer through 10.0.2.2.
// On a physical phone, replace with your computer's LAN IP.
// This is local-development HTTP only. Use HTTPS for production.
private const val API_BASE = "http://10.0.2.2:3000"
private val http = OkHttpClient()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { RiderHome() } }
    }
}

private suspend fun api(method: String, path: String, payload: JSONObject? = null): String =
    withContext(Dispatchers.IO) {
        val builder = Request.Builder().url(API_BASE + path)
        if (method == "POST") {
            builder.post((payload?.toString() ?: "{}").toRequestBody("application/json".toMediaType()))
        } else builder.get()
        http.newCall(builder.build()).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException(body)
            body
        }
    }

@Composable
private fun RiderHome() {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("Demo Customer") }
    var phone by remember { mutableStateOf("") }
    var customerId by remember { mutableStateOf("") }
    var pickup by remember { mutableStateOf("मेरी लोकेशन") }
    var destination by remember { mutableStateOf("") }
    var vehicle by remember { mutableStateOf("bike") }
    var payment by remember { mutableStateOf("cash") }
    var message by remember { mutableStateOf("पहले रजिस्टर करें, फिर राइड बुक करें।") }
    var busy by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("🚕 Infoo Rider", style = MaterialTheme.typography.headlineMedium)
        Text("Ride Smart · Live Better")
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("आपका नाम") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = phone, onValueChange = { phone = it.filter(Char::isDigit).take(10) }, label = { Text("10 अंकों का मोबाइल नंबर") }, modifier = Modifier.fillMaxWidth())
        Button(
            enabled = !busy && name.isNotBlank() && phone.length == 10,
            onClick = {
                busy = true
                scope.launch {
                    try {
                        val result = api("POST", "/api/users", JSONObject()
                            .put("name", name.trim()).put("phone", phone).put("role", "customer"))
                        customerId = JSONObject(result).getInt("id").toString()
                        message = "रजिस्ट्रेशन सफल। Customer ID: $customerId"
                    } catch (e: Exception) {
                        message = "रजिस्ट्रेशन नहीं हुआ: ${e.message ?: "API error"}"
                    } finally { busy = false }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (busy) "कृपया प्रतीक्षा करें…" else "ग्राहक रजिस्टर करें") }

        OutlinedTextField(value = customerId, onValueChange = { customerId = it.filter(Char::isDigit) }, label = { Text("Customer ID") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = pickup, onValueChange = { pickup = it }, label = { Text("Pickup") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = destination, onValueChange = { destination = it }, label = { Text("Destination") }, modifier = Modifier.fillMaxWidth())

        Text("वाहन चुनें", modifier = Modifier.padding(top = 12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("bike", "auto", "car").forEach { type ->
                FilterChip(selected = vehicle == type, onClick = { vehicle = type }, label = { Text(type.uppercase()) })
            }
        }
        Text("पेमेंट", modifier = Modifier.padding(top = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("cash", "upi").forEach { type ->
                FilterChip(selected = payment == type, onClick = { payment = type }, label = { Text(type.uppercase()) })
            }
        }
        Button(
            enabled = !busy && customerId.toIntOrNull() != null && pickup.isNotBlank() && destination.isNotBlank(),
            onClick = {
                busy = true
                scope.launch {
                    try {
                        val result = api("POST", "/api/rides", JSONObject()
                            .put("customerId", customerId.toInt())
                            .put("pickup", pickup.trim())
                            .put("destination", destination.trim())
                            .put("vehicleType", vehicle)
                            .put("paymentMethod", payment))
                        val ride = JSONObject(result)
                        message = "राइड बनाई गई: IR${ride.getInt("id")} · अनुमानित किराया ₹${ride.getInt("estimated_fare")} · स्थिति ${ride.getString("status")}"
                    } catch (e: Exception) {
                        message = "बुकिंग नहीं हुई: ${e.message ?: "API error"}"
                    } finally { busy = false }
                }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
        ) { Text("राइड बुक करें") }
        Text(message, modifier = Modifier.padding(top = 12.dp))
        Text(
            "यह शुरुआती ग्राहक ऐप है। OTP login, live GPS, map, push notifications और UPI payment verification अभी शामिल नहीं हैं.",
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 12.dp)
        )
    }
}
