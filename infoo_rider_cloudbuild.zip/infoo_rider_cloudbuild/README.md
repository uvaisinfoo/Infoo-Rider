# Infoo Rider — Starter Project

This is a development starter for an Android ride-hailing service with:
- Node.js + Express API
- SQLite database
- Basic customer ride booking endpoints
- Driver ride listing and status updates
- Simple admin web dashboard
- Android Kotlin/Jetpack Compose starter app

## Important limitations
This is **not a production-ready ride service** and does not yet include verified phone OTP, secure production admin authentication, live GPS/maps, push notifications, UPI payment verification, driver KYC, or production deployment hardening. Do not use real customer data until authentication, authorization, validation, HTTPS, logging, backups, and security review are implemented.

## 1. Run the backend
Requires Node.js 20+.

```bash
cd backend
npm install
npm start
```

API defaults to `http://localhost:3000`. SQLite database is created automatically at `backend/infoo_rider.db`.

Health check: `GET http://localhost:3000/api/health`

## 2. Open the admin dashboard
After starting the backend, open:
`http://localhost:3000/admin`

This starter dashboard lists bookings and lets an admin demo-update ride statuses. It is intentionally a local development panel, **not secured for public internet use**.

## 3. Test the API

Create a customer:
```bash
curl -X POST http://localhost:3000/api/users \
  -H "Content-Type: application/json" \
  -d '{"name":"Demo Customer","phone":"9999999999","role":"customer"}'
```

Create a ride (replace `1` with the returned user id):
```bash
curl -X POST http://localhost:3000/api/rides \
  -H "Content-Type: application/json" \
  -d '{"customerId":1,"pickup":"Railway Station","destination":"Civil Lines","vehicleType":"bike","paymentMethod":"cash"}'
```

List open rides as a driver:
```bash
curl "http://localhost:3000/api/driver/rides?driverId=2"
```

Accept a ride:
```bash
curl -X PATCH http://localhost:3000/api/rides/1/status \
  -H "Content-Type: application/json" \
  -d '{"status":"accepted","driverId":2}'
```

Allowed statuses: `requested`, `accepted`, `arriving`, `started`, `completed`, `cancelled`.

## 4. Android starter
Open `android/` in Android Studio. The Kotlin file is a UI starter and shows how to call the API. For an emulator, Android can reach the host computer at `http://10.0.2.2:3000`. For a physical phone, use your computer's LAN IP and ensure both devices are on the same network. Cleartext HTTP is enabled for local development only; production must use HTTPS.

## 5. Before a real launch
1. Add OTP authentication and role-based authorization.
2. Add secure admin login and audit logs.
3. Add Google Maps/Mapbox with location permissions and driver location updates.
4. Add a payment provider/UPI intent flow and server-side payment verification. Never mark a payment paid just because the client says so.
5. Add notifications, rate limits, input validation, privacy policy, terms, emergency/support workflow, and backups.
6. Deploy behind HTTPS with secrets stored in environment variables.
7. Complete driver verification and comply with applicable local transport, tax, privacy, and platform requirements.
